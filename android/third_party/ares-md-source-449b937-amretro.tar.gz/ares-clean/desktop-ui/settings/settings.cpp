#include "../desktop-ui.hpp"
#include <nall/vector-helpers.hpp>
#include "video.cpp"
#include "audio.cpp"
#include "input.cpp"
#include "hotkeys.cpp"
#include "emulators.cpp"
#include "options.cpp"
#include "firmware.cpp"
#include "paths.cpp"
#include "cores.cpp"
#include "developer.cpp"
#include "importexport.cpp"
#include "home.cpp"

Settings settings;
namespace Instances { Instance<SettingsWindow> settingsWindow; }
SettingsWindow& settingsWindow = Instances::settingsWindow();
VideoSettings& videoSettings = settingsWindow.videoSettings;
AudioSettings& audioSettings = settingsWindow.audioSettings;
InputSettings& inputSettings = settingsWindow.inputSettings;
HotkeySettings& hotkeySettings = settingsWindow.hotkeySettings;
EmulatorSettings& emulatorSettings = settingsWindow.emulatorSettings;
OptionSettings& optionSettings = settingsWindow.optionSettings;
FirmwareSettings& firmwareSettings = settingsWindow.firmwareSettings;
PathSettings& pathSettings = settingsWindow.pathSettings;
DeveloperSettings& developerSettings = settingsWindow.developerSettings;
CoreSettings& coreSettings = settingsWindow.coreSettings;
ImportExportSettings& importExportSettings = settingsWindow.importExportSettings;

auto Settings::load() -> void {
  Markup::Node::operator=(BML::unserialize(string::read(filePath), " "));
  process(true);
  save();
}

auto Settings::save() -> void {
  process(false);
  file::write(filePath, BML::serialize(*this, " "));
}

auto Settings::process(bool load) -> void {
  if(load) {
    //initialize non-static default settings
    video.driver = ruby::Video::optimalDriver();
    audio.driver = "SDL";
    input.driver = "SDL";
  }

  #define bind(type, path, name) \
    if(load) { \
      if(auto node = operator[](path)) name = node.type(); \
    } else { \
      operator()(path).setValue(name); \
    } \

  bind(string,  "Video/Driver", video.driver);
  bind(string,  "Video/Monitor", video.monitor);
  bind(string,  "Video/Format", video.format);
  bind(boolean, "Video/Exclusive", video.exclusive);
  bind(boolean, "Video/Blocking", video.blocking);
  bind(boolean, "Video/PresentSRGB", video.forceSRGB);
  bind(boolean, "Video/ThreadedRenderer", video.threadedRenderer);
  bind(boolean, "Video/NativeFullScreen", video.nativeFullScreen);
  bind(boolean, "Video/Flush", video.flush);
  bind(string,  "Video/Shader", video.shader);
  bind(natural, "Video/WindowWidth", video.windowWidth);
  bind(natural, "Video/WindowHeight", video.windowHeight);
  bind(string,  "Video/Output", video.output);
  bind(natural, "Video/FixedScale", video.fixedScale);
  bind(string,  "Video/AspectCorrectionMode", video.aspectCorrection);
  bind(boolean, "Video/AdaptiveSizing", video.adaptiveSizing);
  bind(boolean, "Video/AutoCentering", video.autoCentering);
  bind(real,    "Video/Luminance", video.luminance);
  bind(real,    "Video/Saturation", video.saturation);
  bind(real,    "Video/Gamma", video.gamma);
  bind(boolean, "Video/ColorBleed", video.colorBleed);
  bind(boolean, "Video/ColorEmulation", video.colorEmulation);
  bind(boolean, "Video/InterframeBlending", video.interframeBlending);
  bind(boolean, "Video/Overscan", video.overscan);
  bind(boolean, "Video/PixelAccuracy", video.pixelAccuracy);

  bind(string,  "Audio/Device", audio.device);
  bind(natural, "Audio/Frequency", audio.frequency);
  bind(natural, "Audio/Latency", audio.latency);
  bind(boolean, "Audio/Blocking", audio.blocking);
  bind(boolean, "Audio/Dynamic", audio.dynamic);
  bind(boolean, "Audio/Mute", audio.mute);
  bind(real,    "Audio/Volume", audio.volume);
  bind(real,    "Audio/Balance", audio.balance);

  bind(string,  "Input/Defocus", input.defocus);

  bind(boolean, "Boot/Fast", boot.fast);
  bind(boolean, "Boot/Debugger", boot.debugger);
  bind(boolean, "Boot/AwaitGDBClient", boot.awaitGDBClient);
  bind(string,  "Boot/Prefer", boot.prefer);

  bind(boolean, "General/ShowStatusBar", general.showStatusBar);
  bind(boolean, "General/Rewind", general.rewind);
  bind(boolean, "General/RunAhead", general.runAhead);
  bind(boolean, "General/AutoSaveMemory", general.autoSaveMemory);
  bind(boolean, "General/NoFilePrompt", general.noFilePrompt);

  bind(natural, "Rewind/Length", rewind.length);
  bind(natural, "Rewind/Frequency", rewind.frequency);
  bind(boolean, "Rewind/Mute", rewind.mute);

  bind(string,  "Paths/Home", paths.home);
  bind(string,  "Paths/Firmware", paths.firmware);
  bind(string,  "Paths/Saves", paths.saves);
  bind(string,  "Paths/Screenshots", paths.screenshots);
  bind(string,  "Paths/Debugging", paths.debugging);
  bind(string,  "Paths/ArcadeRoms", paths.arcadeRoms);
  bind(string,  "Paths/SuperFamicom/GameBoy", paths.superFamicom.gameBoy);
  bind(string,  "Paths/SuperFamicom/BSMemory", paths.superFamicom.bsMemory);
  bind(string,  "Paths/SuperFamicom/SufamiTurbo", paths.superFamicom.sufamiTurbo);

  bind(natural, "Developer/DebugServerPort", developer.debugServerPort);
  bind(boolean, "Developer/DebugServerEnabled", developer.debugServerEnabled);
  bind(boolean, "Developer/DebugServerUseIPv4", developer.debugServerUseIPv4);
  bind(boolean, "Developer/HomebrewMode", developer.homebrewMode);
  bind(boolean, "Developer/ForceInterpreter", developer.forceInterpreter);

  bind(boolean, "Nintendo64/ExpansionPak", nintendo64.expansionPak);
  bind(string,  "Nintendo64/ControllerPakBankString", nintendo64.controllerPakBankString);
  bind(string,  "Nintendo64/Quality", nintendo64.quality);
  bind(boolean, "Nintendo64/Supersampling", nintendo64.supersampling);
  bind(boolean, "Nintendo64/DisableVideoInterfaceProcessing", nintendo64.disableVideoInterfaceProcessing);
  bind(boolean, "Nintendo64/WeaveDeinterlacing", nintendo64.weaveDeinterlacing);

  bind(boolean, "GameBoyAdvance/Player", gameBoyAdvance.player);

  bind(boolean, "SuperFamicom/DeepBlackBoost", superFamicom.deepBlackBoost);

  bind(boolean, "MegaDrive/TMSS", megadrive.tmss);

  for(u32 index : range(9)) {
    string name = {"Recent/Game-", 1 + index};
    bind(string, name, recent.game[index]);
  }

  for(u32 index : range(5)) {
    auto& port = virtualPorts[index];
    for(auto& input : port.pad.inputs) {
      string name = {"VirtualPad", 1 + index, "/", string{input.name}.replace(" ", ".").replace("(", ".").replace(")", "")}, value;
      if(load == 0) for(auto& assignment : input.mapping->assignments) value.append(assignment, ";");
      if(load == 0) value.trimRight(";", 1L);
      bind(string, name, value);
      if(load == 1) {
        auto parts = nall::split(value, ";");
        parts.resize(BindingLimit);
        for(u32 binding : range(BindingLimit)) input.mapping->assignments[binding] = parts[binding];
      }
    }
    for(auto& input : port.mouse.inputs) {
      string name = {"VirtualMouse", 1 + index, "/", input.name}, value;
      if(load == 0) for(auto& assignment : input.mapping->assignments) value.append(assignment, ";");
      if(load == 0) value.trimRight(";", 1L);
      bind(string, name, value);
      if(load == 1) {
        auto parts = nall::split(value, ";");
        parts.resize(BindingLimit);
        for(u32 binding : range(BindingLimit)) input.mapping->assignments[binding] = parts[binding];
      }
    }
  }

  for(auto& emulator : emulators) {
    string base = string{emulator->name}.replace(" ", "");
    base.replace("(", "").replace(")", "");
    for(auto& port : emulator->ports) {
      for(auto& device : port.devices) {
        if(!device.hasDirectMappings()) continue;
        string portName = string{port.name}.replace(" ", ".").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("*", "Star").replace("#", "Pound");
        string deviceName = string{device.name}.replace(" ", ".").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("*", "Star").replace("#", "Pound");
        for(auto& input : device.inputs) {
          auto& mapping = input.configuredMapping();
          string inputName = string{input.name}.replace(" ", ".").replace("[", "").replace("]", "").replace("(", ".").replace(")", "").replace("*", "Star").replace("#", "Pound");
          string name = {base, "/Input/", portName, "/", deviceName, "/", inputName}, value;
          if(load == 0) for(auto& assignment : mapping.assignments) value.append(assignment, ";");
          if(load == 0) value.trimRight(";", 1L);
          bind(string, name, value);
          if(load == 1) {
            auto parts = nall::split(value, ";");
            parts.resize(BindingLimit);
            for(u32 binding : range(BindingLimit)) mapping.assignments[binding] = parts[binding];
          }
        }
        for(auto& pair : device.pairs) {
          string pairName = string{pair.name}.replace(" ", ".").replace("[", "").replace("]", "").replace("(", ".").replace(")", "").replace("*", "Star").replace("#", "Pound");
          for(auto index : range(2)) {
            string suffix = index == 0 ? "Lo" : "Hi";
            auto& mapping = index == 0 ? pair.configuredMappingLo() : pair.configuredMappingHi();
            string name = {base, "/Input/", portName, "/", deviceName, "/", pairName, "/", suffix}, value;
            if(load == 0) for(auto& assignment : mapping.assignments) value.append(assignment, ";");
            if(load == 0) value.trimRight(";", 1L);
            bind(string, name, value);
            if(load == 1) {
              auto parts = nall::split(value, ";");
              parts.resize(BindingLimit);
              for(u32 binding : range(BindingLimit)) mapping.assignments[binding] = parts[binding];
            }
          }
        }
      }
    }
  }

  for(auto& mapping : inputManager.hotkeys) {
    string name = {"Hotkey/", string{mapping.name}.replace(" ", "")}, value;
    if(load == 0) for(auto& assignment : mapping.assignments) value.append(assignment, ";");
    if(load == 0) value.trimRight(";", 1L);
    bind(string, name, value);
    if(load == 1) {
      auto parts = nall::split(value, ";");
      parts.resize(BindingLimit);
      for(u32 binding : range(BindingLimit)) mapping.assignments[binding] = parts[binding];
    }
  }

  for(auto& emulator : emulators) {
    string base = string{emulator->name}.replace(" ", ""), name;
    base.replace("(", "").replace(")", "");
    name = {base, "/Visible"};
    bind(boolean, name, emulator->configuration.visible);
    name = {base, "/Path"};
    bind(string,  name, emulator->configuration.game);
    for(auto& firmware : emulator->firmware) {
      string name = {base, "/Firmware/", firmware.type, ".", firmware.region};
      name.replace(" ", "-");
      bind(string, name, firmware.location);
    }
  }

  #undef bind
}

//

auto SettingsWindow::initialize() -> void {
  onClose([&] {
    settings.save();
    setVisible(false);
    //cancel any pending input assignment requests, if any
    inputSettings.setVisible(false);
    hotkeySettings.setVisible(false);
  });

  panelContainer.setPadding(5_sx, 5_sy);

  panelList.append(ListViewItem().setText("Video").setIcon(Icon::Device::Display));
  panelList.append(ListViewItem().setText("Audio").setIcon(Icon::Device::Speaker));
  panelList.append(ListViewItem().setText("Input").setIcon(Icon::Device::Joypad));
  panelList.append(ListViewItem().setText("Hotkeys").setIcon(Icon::Device::Keyboard));
  panelList.append(ListViewItem().setText("Emulators").setIcon(Icon::Place::Server));
  panelList.append(ListViewItem().setText("Options").setIcon(Icon::Action::Settings));
  panelList.append(ListViewItem().setText("Firmware").setIcon(Icon::Emblem::Binary));
  panelList.append(ListViewItem().setText("Paths").setIcon(Icon::Emblem::Folder));
  panelList.append(ListViewItem().setText("Cores").setIcon(Icon::Place::Settings));
  panelList.append(ListViewItem().setText("Developer").setIcon(Icon::Device::Network));
  panelList.append(ListViewItem().setText("Settings File").setIcon(Icon::Action::Save));
  panelList->setUsesSidebarStyle();
  panelList.onChange([&] { eventChange(); });

  panelContainer.append(videoSettings, Size{~0, ~0});
  panelContainer.append(audioSettings, Size{~0, ~0});
  panelContainer.append(inputSettings, Size{~0, ~0});
  panelContainer.append(hotkeySettings, Size{~0, ~0});
  panelContainer.append(emulatorSettings, Size{~0, ~0});
  panelContainer.append(optionSettings, Size{~0, ~0});
  panelContainer.append(firmwareSettings, Size{~0, ~0});
  panelContainer.append(pathSettings, Size{~0, ~0});
  panelContainer.append(coreSettings, Size{~0, ~0});
  panelContainer.append(developerSettings, Size{~0, ~0});
  panelContainer.append(importExportSettings, Size{~0, ~0});
  panelContainer.append(homePanel, Size{~0, ~0});

  videoSettings.construct();
  audioSettings.construct();
  inputSettings.construct();
  hotkeySettings.construct();
  emulatorSettings.construct();
  optionSettings.construct();
  firmwareSettings.construct();
  pathSettings.construct();
  coreSettings.construct();
  developerSettings.construct();
  importExportSettings.construct();
  homePanel.construct();

  setDismissable();
  setTitle("Configuration");
  setSize({700_sx, 450_sy});
  setAlignment({0.0, 1.0});
  setResizable(false);
  
  videoSettings.videoRefresh();
  audioSettings.audioRefresh();
  initialized = true;
}

auto SettingsWindow::show(const string& panel) -> void {
  if(!initialized) initialize();
  for(auto item : panelList.items()) {
    if(item.text() == panel) {
      item.setSelected();
      eventChange();
      break;
    }
  }
  setVisible();
  setFocused();
  panelList.setFocused();
}

auto SettingsWindow::eventChange() -> void {
  videoSettings.setVisible(false);
  audioSettings.setVisible(false);
  inputSettings.setVisible(false);
  hotkeySettings.setVisible(false);
  emulatorSettings.setVisible(false);
  optionSettings.setVisible(false);
  firmwareSettings.setVisible(false);
  pathSettings.setVisible(false);
  coreSettings.setVisible(false);
  developerSettings.setVisible(false);
  importExportSettings.setVisible(false);
  homePanel.setVisible(false);

  bool found = false;
  if(auto item = panelList.selected()) {
    if(item.text() == "Video"    ) found = true, videoSettings.setVisible();
    if(item.text() == "Audio"    ) found = true, audioSettings.setVisible();
    if(item.text() == "Input"    ) found = true, inputSettings.setVisible();
    if(item.text() == "Hotkeys"  ) found = true, hotkeySettings.setVisible();
    if(item.text() == "Emulators") found = true, emulatorSettings.setVisible();
    if(item.text() == "Options"  ) found = true, optionSettings.setVisible();
    if(item.text() == "Firmware" ) found = true, firmwareSettings.setVisible();
    if(item.text() == "Paths"    ) found = true, pathSettings.setVisible();
    if(item.text() == "Cores"    ) found = true, coreSettings.setVisible();
    if(item.text() == "Developer"    ) found = true, developerSettings.setVisible();
    if(item.text() == "Settings File") found = true, importExportSettings.setVisible(); 
  }
  if(!found) homePanel.setVisible();

  panelContainer.resize();
}
