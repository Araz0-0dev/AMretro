#if defined(PLATFORM_WINDOWS) || defined(PLATFORM_MACOS)
  constexpr u32 layoutVertSize = 14;
#else
  constexpr u32 layoutVertSize = 18;
#endif

struct Settings : Markup::Node {
  using string = nall::string;

  auto load() -> void;
  auto save() -> void;
  auto process(bool load) -> void;

  string filePath;

  struct Video {
    string driver;
    string monitor;
    string format;
    bool exclusive = false;
    bool blocking = false;
    bool forceSRGB = false;
    bool threadedRenderer = true;
    bool nativeFullScreen = false;
    bool flush = false;
    string shader = "None";
    u32 windowWidth = 800;
    u32 windowHeight = 576;
    string output = "Scale";
    u32 fixedScale = 2;
    string aspectCorrection = "Standard";
    bool adaptiveSizing = true;
    bool autoCentering = false;

    f64 luminance = 1.0;
    f64 saturation = 1.0;
    f64 gamma = 1.0;
    bool colorBleed = false;
    bool colorEmulation = true;
    bool interframeBlending = true;
    bool overscan = true;
    bool pixelAccuracy = false;
  } video;

  struct Audio {
    string driver;
    string device;
    u32 frequency = 0;
    u32 latency = 0;
    bool exclusive = false;
    bool blocking = true;
    bool dynamic = false;
    bool mute = false;

    f64 volume = 1.0;
    f64 balance = 0.0;
  } audio;

  struct Input {
    string driver;
    string defocus = "Pause";
  } input;

  struct Boot {
    bool fast = false;
    bool debugger = false;
    bool awaitGDBClient = false;
    string prefer = "NTSC-U";
  } boot;

  struct General {
    bool showStatusBar = true;
    bool rewind = false;
    bool runAhead = false;
    bool autoSaveMemory = true;
    bool noFilePrompt = false;
  } general;

  struct Rewind {
    u32 length = 80;
    u32 frequency = 60;
    bool mute = false;
  } rewind;

  struct Paths {
    string home;
    string firmware;
    string saves;
    string screenshots;
    string debugging;
    string arcadeRoms;
    struct SuperFamicom {
      string gameBoy;
      string bsMemory;
      string sufamiTurbo;
    } superFamicom;
  } paths;

  struct Recent {
    string game[9];
  } recent;

  struct Developer {
    u32  debugServerPort = 9123;
    bool debugServerEnabled = false; // if enabled, server starts with ares
    bool debugServerUseIPv4 = false; // forces IPv4 over IPv6
    bool homebrewMode = false;
    bool forceInterpreter = false;
  } developer;

  struct Nintendo64 {
    bool expansionPak = true;
    u8 controllerPakBankCount = 1;
    string controllerPakBankString = "32KiB (Default)";
    string quality = "SD";
    bool supersampling = false;
    bool disableVideoInterfaceProcessing = false;
    bool weaveDeinterlacing = true;
  } nintendo64;

  struct GameBoyAdvance {
    bool player = false;
  } gameBoyAdvance;

  struct SuperFamicom {
    bool deepBlackBoost = false;
  } superFamicom;

  struct MegaDrive {
    bool tmss = false;
  } megadrive;
};

struct VideoSettings : VerticalLayout {
  auto construct() -> void;
  auto videoRefresh() -> void;
  auto videoDriverUpdate() -> bool;

  Label colorAdjustmentLabel{this, Size{~0, 0}, 5};
  TableLayout colorAdjustmentLayout{this, Size{~0, 0}};
    Label luminanceLabel{&colorAdjustmentLayout, Size{0, 0}};
    Label luminanceValue{&colorAdjustmentLayout, Size{50_sx, 0}};
    HorizontalSlider luminanceSlider{&colorAdjustmentLayout, Size{~0, 0}};
  //
    Label saturationLabel{&colorAdjustmentLayout, Size{0, 0}};
    Label saturationValue{&colorAdjustmentLayout, Size{50_sx, 0}};
    HorizontalSlider saturationSlider{&colorAdjustmentLayout, Size{~0, 0}};
  //
    Label gammaLabel{&colorAdjustmentLayout, Size{0, 0}};
    Label gammaValue{&colorAdjustmentLayout, Size{50_sx, 0}};
    HorizontalSlider gammaSlider{&colorAdjustmentLayout, Size{~0, 0}};
  //
  Label emulatorSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout colorBleedLayout{this, Size{~0, 0}, 5};
      CheckLabel colorBleedOption{&colorBleedLayout, Size{0, 0}, 5};
      Label colorBleedHint{&colorBleedLayout, Size{~0, layoutVertSize}};
    HorizontalLayout colorEmulationLayout{this, Size{~0, 0}, 5};
      CheckLabel colorEmulationOption{&colorEmulationLayout, Size{0, 0}, 5};
      Label colorEmulationHint{&colorEmulationLayout, Size{~0, layoutVertSize}};
    HorizontalLayout interframeBlendingLayout{this, Size{~0, 0}, 5};
      CheckLabel interframeBlendingOption{&interframeBlendingLayout, Size{0, 0}, 5};
      Label interframeBlendingHint{&interframeBlendingLayout, Size{~0, layoutVertSize}};
    HorizontalLayout overscanLayout{this, Size{~0, 0}};
      CheckLabel overscanOption{&overscanLayout, Size{0, 0}, 5};
      Label overscanHint{&overscanLayout, Size{~0, layoutVertSize}};
    HorizontalLayout pixelAccuracyLayout{this, Size{~0, 0}};
      CheckLabel pixelAccuracyOption{&pixelAccuracyLayout, Size{0, 0}, 5};
      Label pixelAccuracyHint{&pixelAccuracyLayout, Size{~0, layoutVertSize}};
  //
    Label videoLabel{this, Size{~0, 0}, 5};
    HorizontalLayout videoDriverLayout{this, Size{~0, 0}};
      Label videoDriverLabel{&videoDriverLayout, Size{0, 0}};
      ComboButton videoDriverList{&videoDriverLayout, Size{0, 0}};
    HorizontalLayout videoPropertyLayout{this, Size{~0, 0}};
      Label videoMonitorLabel{&videoPropertyLayout, Size{0, 0}};
      ComboButton videoMonitorList{&videoPropertyLayout, Size{0, 0}};
      Label videoFormatLabel{&videoPropertyLayout, Size{0, 0}};
      ComboButton videoFormatList{&videoPropertyLayout, Size{0, 0}};
    HorizontalLayout videoToggleLayout{this, Size{~0, 0}};
#if !defined(PLATFORM_MACOS)
    CheckLabel videoExclusiveToggle{&videoToggleLayout, Size{0, 0}};
#endif
#if defined(PLATFORM_MACOS)
    CheckLabel videoColorSpaceToggle{&videoToggleLayout, Size{0, 0}};
    CheckLabel videoThreadedRendererToggle{&videoToggleLayout, Size{0, 0}};
    CheckLabel videoNativeFullScreenToggle{&videoToggleLayout, Size{0, 0}};
#endif
};

struct AudioSettings : VerticalLayout {
  auto construct() -> void;
  auto audioRefresh() -> void;
  auto audioDriverUpdate() -> bool;

  Label effectsLabel{this, Size{~0, 0}, 5};
  TableLayout effectsLayout{this, Size{~0, 0}};
    Label volumeLabel{&effectsLayout, Size{0, 0}};
    Label volumeValue{&effectsLayout, Size{50_sx, 0}};
    HorizontalSlider volumeSlider{&effectsLayout, Size{~0, 0}};
    Label balanceLabel{&effectsLayout, Size{0, 0}};
    Label balanceValue{&effectsLayout, Size{50_sx, 0}};
    HorizontalSlider balanceSlider{&effectsLayout, Size{~0, 0}};
  Label audioLabel{this, Size{~0, 0}, 5};
  HorizontalLayout audioDeviceLayout{this, Size{~0, 0}};
    Label audioDeviceLabel{&audioDeviceLayout, Size{0, 0}};
    ComboButton audioDeviceList{&audioDeviceLayout, Size{0, 0}};
  HorizontalLayout audioPropertyLayout{this, Size{~0, 0}};
    Label audioFrequencyLabel{&audioPropertyLayout, Size{0, 0}};
    ComboButton audioFrequencyList{&audioPropertyLayout, Size{0, 0}};
    Label audioLatencyLabel{&audioPropertyLayout, Size{0, 0}};
    ComboButton audioLatencyList{&audioPropertyLayout, Size{0, 0}};
    CheckLabel audioDynamicToggle{&audioPropertyLayout, Size{0, 0}};
};

struct InputSettings : VerticalLayout {
  auto construct() -> void;
  auto systemChange() -> void;
  auto portChange() -> void;
  auto deviceChange() -> void;
  auto refresh() -> void;
  auto eventContext(TableViewCell) -> void;
  auto eventChange() -> void;
  auto eventClear() -> void;
  auto eventAssign(TableViewCell, string binding) -> void;
  auto eventAssign(TableViewCell) -> void;
  auto eventInput(std::shared_ptr<HID::Device>, u32 groupID, u32 inputID, s16 oldValue, s16 newValue) -> void;
  auto setVisible(bool visible = true) -> InputSettings&;
  auto inputDriverUpdate() -> bool;

  HorizontalLayout inputDefocusLayout{this, Size{~0, 0}};
    Label inputDefocusLabel{&inputDefocusLayout, Size{0, 0}};
    RadioLabel inputDefocusPause{&inputDefocusLayout, Size{0, 0}};
    RadioLabel inputDefocusBlock{&inputDefocusLayout, Size{0, 0}};
    RadioLabel inputDefocusAllow{&inputDefocusLayout, Size{0, 0}};
    Group inputDefocusGroup{&inputDefocusPause, &inputDefocusBlock, &inputDefocusAllow};
  HorizontalLayout indexLayout{this, Size{~0, 0}};
    ComboButton systemList{&indexLayout, Size{~0, 0}};
    ComboButton portList{&indexLayout, Size{~0, 0}};
    ComboButton deviceList{&indexLayout, Size{~0, 0}};
  Label inputHint{this, Size{~0, 0}, 5};
  TableView inputList{this, Size{~0, ~0}};
  HorizontalLayout controlLayout{this, Size{~0, 0}};
    Label assignLabel{&controlLayout, Size{~0, 0}};
    Canvas spacer{&controlLayout, Size{1, 0}};
    Button assignButton{&controlLayout, Size{80, 0}};
    Button clearButton{&controlLayout, Size{80, 0}};

  maybe<InputNode&> activeMapping;
  u32 activeBinding = 0;
  Timer timer;
  PopupMenu menu;
};

struct HotkeySettings : VerticalLayout {
  auto construct() -> void;
  auto reload() -> void;
  auto refresh() -> void;
  auto eventChange() -> void;
  auto eventClear() -> void;
  auto eventAssign(TableViewCell) -> void;
  auto eventInput(std::shared_ptr<HID::Device>, u32 groupID, u32 inputID, s16 oldValue, s16 newValue) -> void;
  auto setVisible(bool visible = true) -> HotkeySettings&;

  TableView inputList{this, Size{~0, ~0}};
  HorizontalLayout controlLayout{this, Size{~0, 0}};
    Label assignLabel{&controlLayout, Size{~0, 0}};
    Canvas spacer{&controlLayout, Size{1, 0}};
    Button assignButton{&controlLayout, Size{80, 0}};
    Button clearButton{&controlLayout, Size{80, 0}};

  maybe<InputHotkey&> activeMapping;
  u32 activeBinding = 0;
  Timer timer;
};

struct EmulatorSettings : VerticalLayout {
  auto construct() -> void;
  auto eventToggle(TableViewCell cell) -> void;

  Label emulatorLabel{this, Size{~0, 0}, 5};
  TableView emulatorList{this, Size{~0, ~0}};
};

struct OptionSettings : VerticalLayout {
  auto construct() -> void;
  Label synchronizationLabel{this, Size{~0, 0}, 5};
      HorizontalLayout synchronizationLayout{this, Size{~0, 0}};
      ComboButton synchronizationList{&synchronizationLayout, Size{0, 0}};
      Label synchronizationHint{&synchronizationLayout, Size{~0, layoutVertSize}};
  Label commonSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout runAheadLayout{this, Size{~0, 0}, 5};
      CheckLabel runAhead{&runAheadLayout, Size{0, 0}, 5};
      Label runAheadHint{&runAheadLayout, Size{~0, layoutVertSize}};
    HorizontalLayout autoSaveMemoryLayout{this, Size{~0, 0}, 5};
      CheckLabel autoSaveMemory{&autoSaveMemoryLayout, Size{0, 0}, 5};
      Label autoSaveMemoryHint{&autoSaveMemoryLayout, Size{~0, layoutVertSize}};
    HorizontalLayout noFilePromptLayout{this, Size{~0, 0}, 5};
      CheckLabel noFilePromptOption{&noFilePromptLayout, Size{0, 0}, 5};
      Label noFilePromptHint{&noFilePromptLayout, Size{0, layoutVertSize}};
  Label rewindSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout rewindLayout{this, Size{~0, 0}, 5};
      CheckLabel rewind{&rewindLayout, Size{0, 0}, 5};
      Label rewindHint{&rewindLayout, Size{~0, layoutVertSize}};
    HorizontalLayout rewindSettingsLayout{this, Size{~0, 0}, 5};
      Label rewindFrequencyLabel{&rewindSettingsLayout, Size{0, 0}};
      ComboButton rewindFrequencyOption{&rewindSettingsLayout, Size{0, 0}};
      Label rewindLengthLabel{&rewindSettingsLayout, Size{0, 0}};
      ComboButton rewindLengthOption{&rewindSettingsLayout, Size{0, 0}};
      CheckLabel rewindMute{&rewindSettingsLayout, Size{0, 0}};
};

struct FirmwareSettings : VerticalLayout {
  auto construct() -> void;
  auto refresh() -> void;
  auto select(const string& emulator, const string& type, const string& region) -> bool;
  auto eventChange() -> void;
  auto eventAssign() -> void;
  auto eventClear() -> void;
  auto eventScan() -> void;
  auto findFirmware(string sha256) -> string;

  Label firmwareLabel{this, Size{~0, 0}, 5};
  TableView firmwareList{this, Size{~0, ~0}};
  HorizontalLayout controlLayout{this, Size{~0, 0}};
    Button scanButton{&controlLayout, Size{80, 0}};
    Canvas spacer{&controlLayout, Size{~0, 0}};
    Button assignButton{&controlLayout, Size{80, 0}};
    Button clearButton{&controlLayout, Size{80, 0}};

  map<string, string> fileHashes;
};

struct PathSettings : VerticalLayout {
  auto construct() -> void;
  auto refresh() -> void;

  Label homeLabel{this, Size{~0, 0}, 5};
  HorizontalLayout homeLayout{this, Size{~0, 0}};
    LineEdit homePath{&homeLayout, Size{~0, 0}};
    Button homeAssign{&homeLayout, Size{80, 0}};
    Button homeReset{&homeLayout, Size{80, 0}};
  Label firmwareLabel{this, Size{~0, 0}, 5};
    HorizontalLayout firmwareLayout{this, Size{~0, 0}};
    LineEdit firmwarePath{&firmwareLayout, Size{~0, 0}};
    Button firmwareAssign{&firmwareLayout, Size{80, 0}};
    Button firmwareReset{&firmwareLayout, Size{80, 0}};
  Label savesLabel{this, Size{~0, 0}, 5};
  HorizontalLayout savesLayout{this, Size{~0, 0}};
    LineEdit savesPath{&savesLayout, Size{~0, 0}};
    Button savesAssign{&savesLayout, Size{80, 0}};
    Button savesReset{&savesLayout, Size{80, 0}};
  Label screenshotsLabel{this, Size{~0, 0}, 5};
  HorizontalLayout screenshotsLayout{this, Size{~0, 0}};
    LineEdit screenshotsPath{&screenshotsLayout, Size{~0, 0}};
    Button screenshotsAssign{&screenshotsLayout, Size{80, 0}};
    Button screenshotsReset{&screenshotsLayout, Size{80, 0}};
  Label debuggingLabel{this, Size{~0, 0}, 5};
  HorizontalLayout debuggingLayout{this, Size{~0, 0}};
    LineEdit debuggingPath{&debuggingLayout, Size{~0, 0}};
    Button debuggingAssign{&debuggingLayout, Size{80, 0}};
    Button debuggingReset{&debuggingLayout, Size{80, 0}};
  Label arcadeRomsLabel{this, Size{~0, 0}, 5};
  HorizontalLayout arcadeRomsLayout{this, Size{~0, 0}};
    LineEdit arcadeRomsPath{&arcadeRomsLayout, Size{~0, 0}};
    Button arcadeRomsAssign{&arcadeRomsLayout, Size{80, 0}};
    Button arcadeRomsReset{&arcadeRomsLayout, Size{80, 0}};
};

struct CoreSettings : VerticalLayout {
  auto construct() -> void;

  HorizontalLayout settingsLayout{this, Size{~0, 0}};
      Label settingsHint{&settingsLayout, Size{0, layoutVertSize}};
  //
  Label nintendo64SettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout nintendo64ExpansionPakLayout{this, Size{~0, 0}, 5};
      CheckLabel nintendo64ExpansionPakOption{&nintendo64ExpansionPakLayout, Size{0, 0}, 5};
      Label nintendo64ExpansionPakHint{&nintendo64ExpansionPakLayout, Size{0, layoutVertSize}};
    HorizontalLayout nintendo64ControllerPakBankLayout{this, Size{~0, 0}, 5};
      Label nintendo64ControllerPakBankLabel{&nintendo64ControllerPakBankLayout, Size{0, layoutVertSize}};
      ComboButton nintendo64ControllerPakBankOption{&nintendo64ControllerPakBankLayout, Size{0, 0}};
      Label nintendo64ControllerPakBankHint{&nintendo64ControllerPakBankLayout, Size{0, layoutVertSize}};
    HorizontalLayout disableVideoInterfaceProcessingLayout{this, Size{~0, 0}, 5};
      CheckLabel disableVideoInterfaceProcessingOption{&disableVideoInterfaceProcessingLayout, Size{0, 0}, 5};
      Label disableVideoInterfaceProcessingHint{&disableVideoInterfaceProcessingLayout, Size{0, layoutVertSize}};
    HorizontalLayout weaveDeinterlacingLayout{this, Size{~0, 0}, 5};
      CheckLabel weaveDeinterlacingOption{&weaveDeinterlacingLayout, Size{0, 0}, 5};
      Label weaveDeinterlacingHint{&weaveDeinterlacingLayout, Size{0, layoutVertSize}};
    HorizontalLayout renderQualityLayout{this, Size{~0, 0}, 5};
      RadioLabel renderQuality1x{&renderQualityLayout, Size{0, 0}};
      RadioLabel renderQuality2x{&renderQualityLayout, Size{0, 0}};
      RadioLabel renderQuality4x{&renderQualityLayout, Size{0, 0}};
      Group renderQualityGroup{&renderQuality1x, &renderQuality2x, &renderQuality4x};
    HorizontalLayout renderSupersamplingLayout{this, Size{~0, 0}, 5};
      CheckLabel renderSupersamplingOption{&renderSupersamplingLayout, Size{0, 0}, 5};
      Label renderSupersamplingHint{&renderSupersamplingLayout, Size{0, layoutVertSize}};

  Label gameBoyAdvanceSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout gameBoyPlayerLayout{this, Size{~0, 0}, 5};
      CheckLabel gameBoyPlayerOption{&gameBoyPlayerLayout, Size{0, 0}, 5};
      Label gameBoyPlayerHint{&gameBoyPlayerLayout, Size{0, layoutVertSize}};

  Label superFamicomSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout superFamicomDeepBlackBoostLayout{this, Size{~0, 0}, 5};
      CheckLabel superFamicomDeepBlackBoostOption{&superFamicomDeepBlackBoostLayout, Size{0, 0}, 5};
      Label superFamicomDeepBlackBoostHint{&superFamicomDeepBlackBoostLayout, Size{0, layoutVertSize}};

  Label megaDriveSettingsLabel{this, Size{~0, 0}, 5};
    HorizontalLayout megaDriveTmssLayout{this, Size{~0, 0}, 5};
      CheckLabel megaDriveTmssOption{&megaDriveTmssLayout, Size{0, 0}, 5};
      Label megaDriveTmssHint{&megaDriveTmssLayout, Size{0, layoutVertSize}};
};

struct DeveloperSettings : VerticalLayout {
  auto construct() -> void;
  auto infoRefresh() -> void;
  auto serverRefresh() -> void;

  Label gdbLabel{this, Size{~0, 0}, 5};

  HorizontalLayout portLayout{this, Size{~0, 0}, 5};
    Label portLabel{&portLayout, Size{0, 0}};
    LineEdit port{&portLayout, Size{~0, 0}};
    Label portHint{&portLayout, Size{~0, layoutVertSize}};

  HorizontalLayout ipv4Layout{this, Size{~0, 0}, 5};
    CheckLabel ipv4{&ipv4Layout, Size{~0, 0}};

  HorizontalLayout enabledLayout{this, Size{~0, 0}, 5};
    CheckLabel enabled{&enabledLayout, Size{~0, 0}};

  Label connectInfo{this, Size{~0, 30}, 5};

  Label debugOptionsLabel{this, Size{~0, 0}, 5};
  HorizontalLayout homebrewModeLayout{this, Size{~0, 0}, 5};
    CheckLabel homebrewMode{&homebrewModeLayout, Size{0, 0}, 5};
    Label homebrewModeHint{&homebrewModeLayout, Size{~0, layoutVertSize}};
  HorizontalLayout forceInterpreterLayout{this, Size{~0, 0}, 5};
    CheckLabel forceInterpreter{&forceInterpreterLayout, Size{0, 0}, 5};
    Label forceInterpreterHint{&forceInterpreterLayout, Size{0, layoutVertSize}};
};

struct ImportExportSettings : VerticalLayout {
  auto construct() -> void;
  auto refresh() -> void;
  auto setVisible(bool visible = true) -> ImportExportSettings&;

  Label settingsFileLabel{this, Size{~0, 0}, 5};
  TextEdit settingsView{this, Size{~0, ~0}};
  HorizontalLayout controlsLayout{this, Size{~0, 0}};
    CheckLabel useImported{&controlsLayout, Size{~0, 0}, 5};
    Canvas spacer{&controlsLayout, Size{1, 0}};
    Button importButton{&controlsLayout, Size{80, 0}};
    Button exportButton{&controlsLayout, Size{80, 0}};
  
  bool imported = false;
};

struct HomePanel : VerticalLayout {
  auto construct() -> void;

  Canvas canvas{this, Size{~0, ~0}};
};

struct SettingsWindow : Window {
  auto show(const string& panel) -> void;
  auto eventChange() -> void;

  HorizontalLayout layout{this};
    ListView panelList{&layout, Size{125_sx, ~0}};
    VerticalLayout panelContainer{&layout, Size{~0, ~0}};
      VideoSettings videoSettings;
      AudioSettings audioSettings;
      InputSettings inputSettings;
      HotkeySettings hotkeySettings;
      EmulatorSettings emulatorSettings;
      OptionSettings optionSettings;
      FirmwareSettings firmwareSettings;
      PathSettings pathSettings;
      CoreSettings coreSettings;
      DeveloperSettings developerSettings;
      ImportExportSettings importExportSettings;
      HomePanel homePanel;
  
  bool initialized = false;
  
private:
  auto initialize() -> void;
};

extern Settings settings;
namespace Instances { extern Instance<SettingsWindow> settingsWindow; }
extern SettingsWindow& settingsWindow;
extern VideoSettings& videoSettings;
extern AudioSettings& audioSettings;
extern InputSettings& inputSettings;
extern HotkeySettings& hotkeySettings;
extern EmulatorSettings& emulatorSettings;
extern OptionSettings& optionSettings;
extern FirmwareSettings& firmwareSettings;
extern PathSettings& pathSettings;
extern CoreSettings& coreSettings;
extern DeveloperSettings& developerSettings;
extern ImportExportSettings& importExportSettings;
